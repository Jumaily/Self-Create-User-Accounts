<?php
require_once(PATH."classes/ldap.class.php"); 
require_once(PATH."classes/misc.class.php");    
require_once(PATH."classes/sessions.class.php"); $SESSION = new Session();
?>