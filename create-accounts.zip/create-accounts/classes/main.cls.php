<?php
class Main extends SQLite3{
   private $sqliteDB = "dbs/ldap_users.sqlite";
   private $connect;
      
   public function __construct(){
      $this->open($this->sqliteDB);
      $this->connect = new SQLite3($this->sqliteDB);
      if(isset($_POST['email'])){ $this->checkuser($_POST); }
      }
      
   
   public function __destruct(){
      $this->connect->close();
      unset($this->connect);
      }

   
   
   
   function create_user(){
      global $SESSION;
      $fn = $SESSION->get_var('firstname');
      $ln = $SESSION->get_var('lastname');
      $el = $SESSION->get_var('email');
      $ph = preg_replace('/[^0-9_]/','',$SESSION->get_var('phone'));
      $pw = $SESSION->get_var('password');
      $un = $SESSION->get_var('uname');
      
      $sql = "INSERT INTO users (fname,lname,email,passwd,uname,phone,active,iphost) VALUES ";
      $sql .= "('$fn','$ln','$el','$pw','$un','$ph','NO','{$this->getUserIP()}')";
      
      $ret = $this->connect->exec($sql);
      if(!$ret){ echo $db->lastErrorMsg(); }
      else { return "Record created successfully\n"; }
      }
   
   
   
   private function checkuser($vars){
	   global $SESSION;
	   $proceed = true;
	   
	   # phone
	   if(!$this->CheckPhone($vars["phone"])){
         $SESSION->set_var('phone',"Invalid Phone");
         $proceed = false;
         }
         
      # password
	   if(!$this->checkPassword($vars["pass1"],$vars["pass2"])){
		   $SESSION->set_var('password',"Invalid Password (>5 characters long, contains number and characters, & must match");
		   $proceed = false;
	      }
	      
	   # email
      if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$vars["email"])) {
	      $SESSION->set_var('email',"Invalid Email");
	      $proceed = false;
	      }
	   else{
	      $ret = $this->connect->query("SELECT email FROM users WHERE email LIKE '{$vars["email"]}' LIMIT 1");
         $row=$ret->fetchArray(SQLITE3_ASSOC);
         // check for duplicate email
         if($row != false){ 
            $SESSION->set_var('email',"Email Already Exists"); 
            $proceed = false;
            } else{;}
         }
      
      # Username check
      $linkb = $this->connect->query("SELECT uname FROM users WHERE uname LIKE '{$vars["uname"]}' LIMIT 1");
      $row=$linkb->fetchArray(SQLITE3_ASSOC);
      if($row != false){ 
         $SESSION->set_var('uname',"Username Already Exists"); 
         $proceed = false;
         } else{;}
         
      # ok to add user   
      if($proceed){
	      $SESSION->set_var('firstname',$this->cleanInput($vars["firstname"]));
	      $SESSION->set_var('lastname',$this->cleanInput($vars["lastname"]));
	      $SESSION->set_var('email',$this->cleanInput($vars["email"]));
	      $SESSION->set_var('phone',$this->cleanInput($vars["phone"]));
	      $SESSION->set_var('password',sha1($vars["pass1"]));
	      $SESSION->set_var('uname',$this->cleanInput($vars["uname"]));
	      $SESSION->set_var('proceed',true);
         }
      }   
      
      
      
      
   private function checkPassword($passwd1,$passwd2,$regidisp='',$regidispTF=''){
      $pattern_passwd = "/^.*(?=.{5,})(?=.*\d)(?=.*\D).*$/";
      if($passwd1 != $passwd2){ return false; } 
      elseif(!preg_match($pattern_passwd, $passwd2)){ return false; }
      else{ return true; }
      }     
   
  
   private function cleanInput($input) {
      $search = array(
                '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
                '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
                '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
                '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
                );
      $output = preg_replace($search, '', $input);
      return $output;
      }
   
   
   private function CheckPhone($string){
      $numbersOnly = preg_replace('/[^0-9_]/', '', $string);
      $numberOfDigits = strlen($numbersOnly);
      return ($numberOfDigits == 7 or $numberOfDigits == 10)?true:false;
      }   


   function getUserIP() {
      if( array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) {
         if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',')>0) {
            $addr = explode(",",$_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($addr[0]);
            } 
         else { return $_SERVER['HTTP_X_FORWARDED_FOR']; }
         }
      else{ return $_SERVER['REMOTE_ADDR']; }
      } 
        
   
   } 
?>