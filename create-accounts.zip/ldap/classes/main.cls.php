<?php
class Main extends SQLite3{
   private $sqliteDB = "dbs/ldap_users.sqlite";
   private $connect;
   private $LDAP_Host = "ds01.cesb.uky.edu";
      
   public function __construct(){
      $this->open($this->sqliteDB);
      $this->connect = new SQLite3($this->sqliteDB);
      if(isset($_POST['email'])){ 
         $this->checkuser($_POST); 
         }
      }      
   
   public function __destruct(){
      $this->connect->close();
      unset($this->connect);
      }
   
   function create_user(){
      global $SESSION;
      $fn = $SESSION->get_var('firstname');
      $ln = $SESSION->get_var('lastname');
      $el = $SESSION->get_var('email');
      $ph = preg_replace('/[^0-9_]/','',$SESSION->get_var('phone'));
      $pw = $SESSION->get_var('password');
      $un = $SESSION->get_var('uname');
      $labgroup = $SESSION->get_var('group');
      
      $sql = "INSERT INTO users (fname,lname,email,passwd,uname,phone,active,iphost,labgroup) VALUES ";
      $sql .= "('$fn','$ln','$el','$pw','$un','$ph','NO','{$this->getUserIP()}','$labgroup')";

      $ret = $this->connect->exec($sql);
      if(!$ret){ echo $db->lastErrorMsg(); }
      else { return "Record created successfully\n"; }
      }
      
   private function checkuser($vars){
	   global $SESSION;
	   $proceed = true;
	   
	   # phone
	   if(!$this->checkPhone($vars["phone"])){
         $SESSION->set_var('phone',"Invalid Phone");
         $proceed = false;
         }
         
      # password
	   if(!$this->checkPassword($vars["pass1"],$vars["pass2"])){
		   $SESSION->set_var('password',"Invalid Password (>5 characters long, contains number and characters, & must match");
		   $proceed = false;
	      }
	      
	   # email
      if(!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$vars["email"])) {
	      $SESSION->set_var('email',"Invalid Email");
	      $proceed = false;
	      }
	   else{
	      $ret = $this->connect->query("SELECT email FROM users WHERE email LIKE '{$vars["email"]}' LIMIT 1");
         $row=$ret->fetchArray(SQLITE3_ASSOC);
         // check for duplicate email
         if($row != false){ 
            $SESSION->set_var('email',"Email Already Exists"); 
            $proceed = false;
            } else{;}
         }
      
      # Username check
      $linkb = $this->connect->query("SELECT uname FROM users WHERE uname LIKE '{$vars["uname"]}' LIMIT 1");
      $row=$linkb->fetchArray(SQLITE3_ASSOC);
      if(($row)||($this->check_LDAP_User($vars["uname"]))){ 
         $SESSION->set_var('uname',"Username Already Exists"); 
         $proceed = false;
         }
      
      # Check Group Selection
      if((!isset($vars['group'])) || (count($vars['group'])<1)){
         $SESSION->set_var('group',"Please pick one or more group."); 
         $proceed = false;
         }
      
      # Check Captcha
      if($_POST['captcha'] != $_SESSION['captcha']['code']){
         $SESSION->set_var("captchacode", "Security Code Entered Incorrectly");
         $proceed = false;
         }

      # ok to add user   
      if($proceed){
         $labgroup="";
         foreach ($vars['group'] as $g) { $labgroup.="$g,"; } 
         $SESSION->set_var('group',rtrim($labgroup,","));
	      $SESSION->set_var('firstname',$this->cleanInput($vars["firstname"]));
	      $SESSION->set_var('lastname',$this->cleanInput($vars["lastname"]));
	      $SESSION->set_var('email',$this->cleanInput($vars["email"]));
	      $SESSION->set_var('phone',$this->cleanInput($vars["phone"]));
	      $SESSION->set_var('password',sha1($vars["pass1"]));
	      $SESSION->set_var('uname',$this->cleanInput($vars["uname"]));
	      $SESSION->set_var('proceed',true);
         }
      }   
            
   private function check_LDAP_User($u){
      $lc = ldap_connect($this->LDAP_Host);
      ldap_set_option($lc, LDAP_OPT_NETWORK_TIMEOUT, 3); # 3 second timeout limit
      ldap_set_option ($lc, LDAP_OPT_REFERRALS, 0);
      ldap_set_option($lc, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_bind($lc);
      $sr = ldap_search($lc, "ou=people,dc=cesb,dc=uky,dc=edu", "uid=$u");
      $info = ldap_get_entries($lc, $sr);
      if($info['count']){ $UE=true; }
      else{ $UE=false; }
      ldap_close($lc);
      return $UE;
      }
       
   function get_LDAP_Groups(){
      $lc = ldap_connect("ds01.cesb.uky.edu");
      ldap_set_option($lc, LDAP_OPT_NETWORK_TIMEOUT, 3); # 3 second timeout limit
      ldap_set_option ($lc, LDAP_OPT_REFERRALS, 0);
      ldap_set_option($lc, LDAP_OPT_PROTOCOL_VERSION, 3);
      ldap_bind($lc);
      $sr = ldap_search($lc, "ou=requestable,ou=groups,dc=cesb,dc=uky,dc=edu", "objectclass=groupofuniquenames");
      $info = ldap_get_entries($lc, $sr);
      ldap_close($lc);
      return $info;
      }

   private function checkPassword($passwd1,$passwd2,$regidisp='',$regidispTF=''){
      $pattern_passwd = "/^.*(?=.{5,})(?=.*\d)(?=.*\D).*$/";
      if($passwd1 != $passwd2){ return false; } 
      elseif(!preg_match($pattern_passwd, $passwd2)){ return false; }
      else{ return true; }
      }     
  
   private function cleanInput($input) {
      $search = array(
                '@<script[^>]*?>.*?</script>@si',   // Strip out javascript
                '@<[\/\!]*?[^<>]*?>@si',            // Strip out HTML tags
                '@<style[^>]*?>.*?</style>@siU',    // Strip style tags properly
                '@<![\s\S]*?--[ \t\n\r]*>@'         // Strip multi-line comments
                );
      $output = preg_replace($search, '', $input);
      return $output;
      }
   
   private function checkPhone($string){
      $numbersOnly = preg_replace('/[^0-9_]/', '', $string);
      $numberOfDigits = strlen($numbersOnly);
      return ($numberOfDigits == 7 or $numberOfDigits == 10)?true:false;
      }   

   function getUserIP() {
      if( array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER) && !empty($_SERVER['HTTP_X_FORWARDED_FOR']) ) {
         if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',')>0) {
            $addr = explode(",",$_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($addr[0]);
            } 
         else { return $_SERVER['HTTP_X_FORWARDED_FOR']; }
         }
      else{ return $_SERVER['REMOTE_ADDR']; }
      } 
        
   } 
?>